import java.io.IOException;
import java.util.Scanner;
import java.util.Arrays;
public class Paging_OS
{
    int def_size = 10;
    String[] page_map;
    String[] virtual_page_table;
    public Paging_OS(int size, int word_size){
        page_map = new String[size];
        virtual_page_table = new String[size];
        set_virtual_page_table(size, word_size);
        set_page_mapping(size);
        def_size = size;
    }

    public void set_virtual_page_table(int size, int word_size){
        String temp = "";
        Scanner reader = new Scanner(System.in); 
        for(int offset = 0; offset < size; offset++){
            int i = 0;
            for(int elem = 0; elem < word_size; elem++){
                System.out.println("Enter value for offset #" + offset + "[" + elem + "] :");
                String a = reader.next();
                temp = temp + "," + a;
            }
            virtual_page_table[i++] = temp;
            temp = "";
        }
    }

    public void sorted_map(){
        String[] sorted_page = page_map;
        for(int i = 0; i < def_size-1; i++) {
            for (int j = i+1; j < sorted_page.length; j++) {
                if(sorted_page[i].compareTo(sorted_page[j])>0) {
                    String temp = sorted_page[i];
                    sorted_page[i] = sorted_page[j];
                    sorted_page[j] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(sorted_page));
    }

    public void set_page_mapping(int size){
        Scanner reader = new Scanner(System.in);
        for(int offset = 0; offset < size; offset++){
            System.out.println("Enter page number for offset #" + offset + " :");
            String a = reader.next();
            page_map[offset] = a;
        }
    }
    
    public void print(){
        System.out.println("Page Mapping");
        System.out.print("[");
        for(int i = 0; i < def_size; i++){
            System.out.print(page_map[i] + ",");
        }
        System.out.print("]");
        System.out.println();
        System.out.println("Virtual Page Table");
        System.out.print("[");
        for(int i = 0; i < def_size; i++){
            System.out.print(virtual_page_table[i] + ",");
        }
        System.out.print("]");
    }

    public static void main(String[] args){
          Paging_OS p1 = new Paging_OS(2,3);
          p1.sorted_map();
          p1.print();
    }
}
